# Pan context and uncertainty — P4 baseline, P5 digital refinement

Owner scope clarification (2026-10-13): P5 continues with digital reconstruction and scenario-bounded virtual fitment; no physical measurement gate is required. The current proxy is an input to improve, not a verified pan model.

The reconstructed pan is a visual context for design exploration. It must not be used to manufacture a replacement pan or infer a measured Solstice fit.

| Feature | Value / construction | Evidence class |
|---|---|---|
| GM12601240 overall envelope | See `delivery/CURRENT_DIMENSIONS.md`; source values are registered as `PAN_PROXY_PAN_LENGTH`, `PAN_PROXY_PAN_WIDTH` and `PAN_PROXY_PAN_DEPTH` | Published GM product specification; overall only |
| Deep and shallow sump relationship | Deep region beneath removable cover, shallower ribbed extension; tube toward deep-end flange | OEM source-photo topology; no metric calibration |
| Cast outline and internal wall thickness | `PAN_PROXY_PAN_OUTLINE_XY` and `PAN_PROXY_PAN_INNER_SCALE_XY` | Design assumption; not measured wall thickness |
| Floor and shallow shelf | `PAN_PROXY_PAN_FLOOR_Z`, `PAN_PROXY_PAN_SHELF_HEIGHT` and associated size/position inputs | Design assumption; not an actual cavity section |
| Reference cover | `PAN_PROXY_COVER_OUTLINE_XY`, underside, relief and thickness inputs | Design assumption; no stock/height specification |
| Raised cover relief | Named outer/inner diameters, lengths and clipping box in the dimension register | Topology inspired by photo; radius/position unknown |
| Pickup test keep-out | `PAN_PROXY_PICKUP_KEEP_OUT_DIAMETER`, height and centre inputs | Explicit design test case; actual screen outline/clearance unknown |
| Tube test envelope | `PAN_PROXY_TUBE_DIAMETER` and `PAN_PROXY_TUBE_CENTERLINE_XYZ` | Explicit design assumption; actual tube centreline and flex unknown |
| Insert placement | `PAN_PROXY_CAGE_ORIGIN_XYZ` and `PAN_PROXY_CAGE_ROTATION_DEG` | Illustration transform; not measured installed registration |
| Lower wall-to-floor gap | Derived from the named cage-origin and floor inputs; generated summary reports the value | Illustration only; no flow/retention or operating-clearance acceptance |
| Vehicle mounting | No positioned tabs, bosses, bolts or mount holes in new concepts | Unresolved; omission must remain visible in fit claims |

Reference: [official GM pan interior](https://ecommerce-assets.ext.gm.com/assets/products/images/12601240_Alternate1.jpg), [official product](https://parts.gmparts.com/product/gm-genuine-parts-engine-oil-pan-12601240). The retained exact-interface follow-up identifies the pan/cover/baffle screw family but supplies no metric hidden cavity or five-seat coordinates.

The official GM 12601240 interior photo provides qualitative exact-part topology but no calibrated internal coordinates. Vue service figures 1868082/1318093 are application-unresolved; figure 1866784 is an LY7/12666374 analog. See the [source applicability assessment](../../research/same-pan-family-visuals.md); none supplies pan, seat or pickup dimensions.

Full-pan cutaway images remove part of one side wall to expose the insert. Detail views additionally crop the shallow extension. Section models remove one half through X=0; this can hide side gates and is not an instruction to remove parts. Exploded views move the insert and cover vertically for explanation, without modelling a proven removal path or mounting connection. All numeric proxy inputs and geometry construction dimensions live in `src/design_parameters.py`; the register and generated summary are derivative views.

All render views use the same source placement. Grey is the assumed pan/cover context; purple is the assumed pickup/tube test envelope; blue/teal is custom structure and gold is the custom moving leaf. Real source photography remains separate from rendered concept geometry.

The P5 validator also checks four one-variable stress cases alongside the nominal proxy: cover underside −12 mm; pickup and tube diameters +25%; pickup and tube centerline +12/−8 mm in X/Y; and pan-interior scale −0.04 in X/Y. These are deliberately selected sensitivities, not confidence bounds. The exact A/B/C outcomes and tested poses are recorded in [`review/digital-fit-scenario-assessment.md`](../../review/digital-fit-scenario-assessment.md). The Honda precedents in [`research/honda-precedents.md`](../../research/honda-precedents.md) inform architectural comparisons, never these Solstice proxy dimensions.

Straight vertical withdrawal is sampled at 1 mm increments from the nominal closed-door placement, with the cover removed. A/B/C hit the rising tube proxy at 7 mm lift (4 mm in the 25%-larger tube case). If the complete pickup/tube proxy is omitted, the sampled path clears in four shell contexts; nested C begins in shell interference under the narrowed-shell case. Eight alternative routes per concept also test ±20 mm shifts along X/Y or ±5° tilts about X/Y before lifting. Translation uses 1 mm samples; rotation uses 1° samples around the insert bounding-box centre. All 24 selected routes meet the nominal tube or shell proxy, with first contacts at 10–13 mm of lateral shift, 2–3° of tilt, or during lift. These sampled first-hit results neither prove all possible paths are blocked nor establish a continuous/actual service path. The exact pickup/tube geometry and suction-pipe removal sequence remain unknown.

# Pan context and uncertainty — P4

The reconstructed pan is a visual context for design exploration. It must not be used to manufacture a replacement pan or infer a measured Solstice fit.

| Feature | Value / construction | Evidence class |
|---|---|---|
| GM12601240 overall envelope | See `delivery/CURRENT_DIMENSIONS.md`; source values are registered as `PAN_PROXY_PAN_LENGTH`, `PAN_PROXY_PAN_WIDTH` and `PAN_PROXY_PAN_DEPTH` | Published GM product specification; overall only |
| Deep and shallow sump relationship | Deep region beneath removable cover, shallower ribbed extension; tube toward deep-end flange | OEM source-photo topology; no metric calibration |
| Cast outline and internal wall thickness | `PAN_PROXY_PAN_OUTLINE_XY` and `PAN_PROXY_PAN_INNER_SCALE_XY` | Design assumption; not measured wall thickness |
| Floor and shallow shelf | `PAN_PROXY_PAN_FLOOR_Z`, `PAN_PROXY_PAN_SHELF_HEIGHT` and associated size/position inputs | Design assumption; not an actual cavity section |
| Reference cover | `PAN_PROXY_COVER_OUTLINE_XY`, underside, relief and thickness inputs | Design assumption; no stock/height specification |
| Raised cover relief | Named outer/inner diameters, lengths and clipping box in the dimension register | Topology inspired by photo; radius/position unknown |
| Pickup test keep-out | `PAN_PROXY_PICKUP_KEEP_OUT_DIAMETER`, height and centre inputs | Explicit design test case; actual screen outline/clearance unknown |
| Tube test envelope | `PAN_PROXY_TUBE_DIAMETER` and `PAN_PROXY_TUBE_CENTERLINE_XYZ` | Explicit design assumption; actual tube centreline and flex unknown |
| Insert placement | `PAN_PROXY_CAGE_ORIGIN_XYZ` and `PAN_PROXY_CAGE_ROTATION_DEG` | Illustration transform; not measured installed registration |
| Lower wall-to-floor gap | Derived from the named cage-origin and floor inputs; generated summary reports the value | Illustration only; no flow/retention or operating-clearance acceptance |
| Vehicle mounting | No positioned tabs, bosses, bolts or mount holes in new concepts | Unresolved; omission must remain visible in fit claims |

Reference: [official GM pan interior](https://ecommerce-assets.ext.gm.com/assets/products/images/12601240_Alternate1.jpg), [official product](https://parts.gmparts.com/product/gm-genuine-parts-engine-oil-pan-12601240). The retained exact-interface follow-up identifies the pan/cover/baffle screw family but supplies no metric hidden cavity or five-seat coordinates.

Full-pan cutaway images remove part of one side wall to expose the insert. Detail views additionally crop the shallow extension. Section models remove one half through X=0; this can hide side gates and is not an instruction to remove parts. Exploded views move the insert and cover vertically for explanation, without modelling a proven removal path or mounting connection. All numeric proxy inputs and geometry construction dimensions live in `src/design_parameters.py`; the register and generated summary are derivative views.

All render views use the same source placement. Grey is the assumed pan/cover context; purple is the assumed pickup/tube test envelope; blue/teal is custom structure and gold is the custom moving leaf. Real source photography remains separate from rendered concept geometry.

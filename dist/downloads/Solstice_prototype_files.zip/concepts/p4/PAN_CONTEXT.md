# Pan context and uncertainty — P4

The reconstructed pan is a visual context for design exploration. It must not be used to manufacture a replacement pan or infer a measured Solstice fit.

| Feature | Value / construction | Evidence class |
|---|---|---|
| GM12601240 overall envelope | 474.7 mm long × 316 mm maximum width × 117.99 mm depth | Published GM product specification; overall only |
| Deep and shallow sump relationship | Deep region beneath removable cover, shallower ribbed extension; tube toward deep-end flange | OEM source-photo topology; no metric calibration |
| Cast outline and internal wall thickness | Polygonal approximation; inner outline scaled .90 in X and .95 in Y | Design assumption; not measured wall thickness |
| Floor and shallow shelf | Z=4 floor; Z=74 shallow shelf | Design assumption; not an actual cavity section |
| Reference cover | Asymmetric relief plate, Z=70 underside, 1 mm visual plate | Design assumption; no stock/height specification |
| Raised cover relief | Half-cylinder visual cue | Topology inspired by photo; radius/position unknown |
| Pickup test keep-out | Ø60 × 10 mm cylinder centred (0,112,18) | Explicit design test case; actual screen outline/clearance unknown |
| Tube test envelope | Ø18 mm piecewise route through the concept's relief | Explicit design assumption; actual tube centreline and flex unknown |
| Insert placement | Rotate 180°; translate (0,112,7) mm | Illustration transform; not measured installed registration |
| Lower wall-to-floor gap | 3 mm in the proxy | Illustration only; no flow/retention or operating-clearance acceptance |
| Vehicle mounting | No positioned tabs, bosses, bolts or mount holes in new concepts | Unresolved; omission must remain visible in fit claims |

Reference: [official GM pan interior](https://ecommerce-assets.ext.gm.com/assets/products/images/12601240_Alternate1.jpg), [official product](https://parts.gmparts.com/product/gm-genuine-parts-engine-oil-pan-12601240). The retained exact-interface follow-up identifies the pan/cover/baffle screw family but supplies no metric hidden cavity or five-seat coordinates.

Full-pan cutaway images remove part of one side wall to expose the insert. Detail views additionally crop the shallow extension. Section models remove one half through X=0; this can hide side gates and is not an instruction to remove parts. Exploded views move the insert and cover vertically for explanation, without modelling a proven removal path or mounting connection.

All render views use the same source placement. Grey is the assumed pan/cover context; purple is the assumed pickup/tube test envelope; blue/teal is custom structure and gold is the custom moving leaf. Real source photography remains separate from rendered concept geometry.

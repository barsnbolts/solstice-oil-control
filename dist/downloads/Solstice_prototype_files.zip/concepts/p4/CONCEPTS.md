# Three gated concepts — P4 creative study

The owner's current baseline is the former V3 custom metal cage. The comparison is now **A simple gated well**, **B radial collector**, and **C nested reservoir**. Earlier fixed-divider and purchased-gate designs remain archived alternatives. The owner explicitly authorized broader nominal design exploration; new geometry here develops construction ideas before actual pan measurement.

| Concept | Concrete difference | Intended behavior to test | Principal tradeoff |
|---|---|---|---|
| A — Simple gated well | Former V3 custom-gate baseline with three inward metal leaves and captive hinges | Test local directional retention around the pickup with the fewest current gated walls | Open bottom/front relief and unmeasured floor/mount gaps remain bypasses |
| B — Radial collector | Octagonal well, four diagonal gates and five joined, open-ended guide vanes | Test collection from diagonal quadrants and routing toward the well | Larger vane envelope, more seams, corner hinge/weld access and directional behavior need comparison |
| C — Nested reservoir | Outer reservoir, inner well, six staggered gates and five rim bridges | Compare staged buffering through an outer reservoir before the pickup well | Two serial gate stages may restrict refill; largest footprint, more parts and service operations |

All current numeric footprints, validated CAD envelopes, gate counts and BOM quantities are generated in `../../delivery/CURRENT_DIMENSIONS.md` from `src/design_parameters.py`, both BOMs and `review/validation.json`. A's loose mounting blanks are not a completed attachment pattern. The counts exclude the unresolved vehicle mounting system and are not cost or performance scores.

All custom sheet parts are planar, with nominal SST-048 / 1.2192 mm structural stock and SST-030 / .762 mm leaves. New cut profiles and their matching STEP parts are under this folder's DXF/ and STEP/. Use this folder's BOM.csv for B/C quantities. The shared hinges preserve the calibrated 60° moving-arm stop; a new arrangement still needs new interference checks. Pins require an owner-qualified fabrication and permanent retention process, not sheet cutting.

## How the pan views are constructed

The full-pan and close cutaways place each insert in the deep-sump region, show a pickup/tube test envelope, and leave the tube-side relief facing the pan's deep end. Exploded views lift the reference cover and insert to make the assembly relationship visible; sections show the floor gap and relative height. Interactive models let the viewer orbit these relationships. Gate animations use arbitrary independent phase offsets and do not solve oil forces or opening time.

**The pan is an illustrative packaging reconstruction, not recovered OEM CAD.** Only the published GM 12601240 overall envelope, 474.7 × 316 × 117.99 mm, is source-backed. The outline, internal floor transition, wall thickness, cover contour/height, pickup/tube dimensions and every placement are assumptions informed by the retained source photos. The website displays the official GM photo alongside these views. No five-boss pattern or mounting-hole coordinates have been invented.

The explicit pickup, tube, floor, cover, placement and pan outline inputs are named in `src/design_parameters.py` and enumerated in `../../delivery/DIMENSION_REGISTER.csv`. The lower-wall gap is a display test case, not a recommended bypass gap. This is a design exercise, not recovered pan or pickup geometry.

See PAN_CONTEXT.md for the assumption register. Source photos and the exact-interface report remain the authority for identity/topology, not hidden metric fit. A collision-free proxy scene does not establish drop-in fit. Mount reach, boss heights, cover clamp stack and usable screw engagement remain unresolved.

## Current nominal verification

The saved new solids, cut profiles and BOM are checked through the P4 build. Motion checks sample 0–60° at 5° intervals plus the inherited roof-height critical angle near 43.898°. Independent gate pairs use 0°, 30°, the critical angle and 60° combinations. The full assumed shell, pickup/tube and cover are included in separate proxy checks. Exact coverage and results are saved in review/validation.json; sampled checks do not prove a continuous/tolerance/weld/thermal sweep.

Every cut profile is compared geometrically with its flat STEP, including holes and internal boundaries. Presentation receipts bind each STEP/sidecar to its screenshots, GLB and video. These checks establish the named digital results only. Joining strength, pin retention, actual free movement, refill/retention balance, durability and engine oil-pressure behavior are untested.

The next physical choice is still driven by the measured pan/cover/pickup/mount envelope and a common-condition comparison with the stock system. More gates or a larger chamber do not establish better oil control. Keep the existing coupon as the smallest hinge-process trial; use a complete mock-up for the new envelope and assembly access.

# Three gated concepts — P4 creative study

The owner's current baseline is the former V3 custom metal cage. The comparison is now **A simple gated well**, **B radial collector**, and **C nested reservoir**. Earlier fixed-divider and purchased-gate designs remain archived alternatives. The owner authorized broader design exploration and clarified that the active objective is accurate digital reconstruction and virtual fitment; no physical measurement gate is required for this work.

| Concept | Concrete difference | Intended behavior to test | Principal tradeoff |
|---|---|---|---|
| A — Simple gated well | Former V3 custom-gate baseline with three inward metal leaves and captive hinges | Test local directional retention around the pickup with the fewest current gated walls | Open bottom/front relief and unmeasured floor/mount gaps remain bypasses |
| B — Radial collector | Octagonal well, four diagonal gates and five joined, open-ended guide vanes | Test collection from diagonal quadrants and routing toward the well | Larger vane envelope, more seams, corner hinge/weld access and directional behavior need comparison |
| C — Nested reservoir | Outer reservoir, inner well, six staggered gates and five rim bridges | Compare staged buffering through an outer reservoir before the pickup well | Two serial gate stages may restrict refill; largest footprint, more parts and service operations |

All current numeric footprints, validated CAD envelopes, gate counts and BOM quantities are generated in `../../delivery/CURRENT_DIMENSIONS.md` from `src/design_parameters.py`, both BOMs and `review/validation.json`. A's loose mounting blanks are not a completed attachment pattern. The counts exclude the unresolved vehicle mounting system and are not cost or performance scores.

All custom sheet parts are planar, with nominal SST-048 / 1.2192 mm structural stock and SST-030 / .762 mm leaves. New cut profiles and their matching STEP parts are under this folder's DXF/ and STEP/. Use this folder's BOM.csv for B/C quantities. The shared hinges preserve the calibrated 60° moving-arm stop; a new arrangement still needs new interference checks. Pins require an owner-qualified fabrication and permanent retention process, not sheet cutting.

## How the pan views are constructed

The full-pan and close cutaways place each insert in the deep-sump region, show a pickup/tube test envelope, and leave the tube-side relief facing the pan's deep end. Exploded views lift the reference cover and insert to make the assembly relationship visible; sections show the floor gap and relative height. Interactive models let the viewer orbit these relationships. Gate animations use arbitrary independent phase offsets and do not solve oil forces or opening time.

**The pan is an illustrative packaging reconstruction, not recovered OEM CAD.** Only the published GM 12601240 overall envelope, 474.7 × 316 × 117.99 mm, is source-backed. The outline, internal floor transition, wall thickness, cover contour/height, pickup/tube dimensions and every placement are assumptions informed by the retained source photos. The website displays the official GM photo alongside these views. No five-boss pattern or mounting-hole coordinates have been invented.

The explicit pickup, tube, floor, cover, placement and pan outline inputs are named in `src/design_parameters.py` and enumerated in `../../delivery/DIMENSION_REGISTER.csv`. The lower-wall gap is a display test case, not a recommended bypass gap. This is a design exercise, not recovered pan or pickup geometry.

See PAN_CONTEXT.md for the assumption register. Source photos and the exact-interface report remain the authority for identity/topology, not hidden metric fit. A collision-free proxy scene does not establish drop-in fit. Mount reach, boss heights, cover clamp stack and usable screw engagement remain unresolved.

## Current nominal verification

The saved new solids, cut profiles and BOM are checked through the P4 build. Motion checks sample 0–60° at 5° intervals plus the inherited roof-height critical angle near 43.898°. Independent gate pairs use 0°, 30°, the critical angle and 60° combinations. The full assumed shell, pickup/tube and cover are included in separate proxy checks. Exact coverage and results are saved in review/validation.json; sampled checks do not prove a continuous/tolerance/weld/thermal sweep.

Every cut profile is compared geometrically with its flat STEP, including holes and internal boundaries. Presentation receipts bind each STEP/sidecar to its screenshots, GLB and video. These checks establish the named digital results only. Joining strength, pin retention, actual free movement, refill/retention balance, durability and engine oil-pressure behavior are untested.

## P5 digital fit sensitivity

The current saved solids are checked in five named contexts: nominal; cover underside 12 mm lower; pickup/tube test envelopes 25% larger; pickup/tube route shifted +12/−8 mm in proxy X/Y; and interior scale reduced by 0.04 in X and Y. B is clear in all five. A's rear gate intersects the enlarged and shifted pickup keep-out at high opening angles. C's inner rear/left gates intersect those pickup cases, and its outer body intersects the narrowed shell proxy. The lower cover case is clear for all three at the tested poses.

These values are deliberate one-variable sensitivity choices, not measured uncertainty bounds or likely OEM variants. See [`review/digital-fit-scenario-assessment.md`](../../review/digital-fit-scenario-assessment.md) and machine-readable pose/overlap records in `review/validation.json`. Honda architecture examples are gathered in [`research/honda-precedents.md`](../../research/honda-precedents.md); they do not set any Solstice dimensions.

The validator now checks a straight vertical install/removal route from the nominal closed-door placement, with the cover removed and 1 mm translation samples. With the pickup/tube proxy retained, all three concepts first intersect the rising tube at 7 mm lift; the deliberately enlarged tube case intersects at 4 mm. With the complete pickup/tube proxy omitted, all three clear the sampled path in four pan contexts; C intersects the narrowed shell at the installed pose. Temporarily removing that assembly is only a digital sequence hypothesis; no Solstice service order, attachment access or continuous swept path has been established. The exact per-context result is in `review/validation.json`.

Saved gate solids also carry a static mass-centroid gravity-torque sweep over the sampled opening angles, in seven total cases: level and six deliberately selected 15° effective-gravity tilts. Every gate biases toward closed at level; some gate orientations bias open in selected directions. The detailed per-gate curves are in `review/validation.json`. This is a geometry-only sensitivity result, not oil behavior, measured vehicle attitude, or a gate response-time prediction.

Official GM 12601240 product imagery provides qualitative exact-part topology. Vue service illustrations are application-unresolved or an LY7/12666374 analog; none provides usable internal coordinates. The [evidence note](../../research/same-pan-family-visuals.md) records source applicability. No CAD dimensions changed from these images.

## Captive-pin access and assembly order

Both ends of every pin are now tested with three continuous cylindrical approach envelopes at four assembly stages (312 exact checks). Isolated hinge hardware clears all diameters before wall attachment; wall-attached gate modules clear only the 6 mm envelope. Completed cages and the installed nominal pan proxy block the tested coaxial approaches. This supports investigating pin heading in an alignment fixture before fixed-cheek wall attachment, or a reduced/tapered tool nose. It is a geometric sequence hypothesis, not a qualified joining/heading method. Representative `*_pin_access.step` overlays and the [generated assessment](../../review/pin-tool-access-assessment.md) expose the assumptions and intersecting parts.

The next digital choice is which concept best balances source-visible packaging, editable fit scenarios, directional gate coverage, flow-path openness, envelope, part count and sensitivity. More gates or a larger chamber do not establish better oil control. The existing coupon and physical mock-up plans remain separate future work; they do not block this digital comparison.

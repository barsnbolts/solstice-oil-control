# Current nominal dimensions — generated

Source: `src/design_parameters.py`, `delivery/BOM.csv`, `review/validation.json`.
See `DIMENSION_REGISTER.csv` for each parameter's datum, source, uncertainty and status.

- Assumed envelope: 160 × 120 × 47.2192 mm.
- Nominal sheet / leaf thickness: 1.2192 / 0.762 mm.
- Custom door stop: 60°.
- Cut quantities V1 / V2 / V3: 8 / 10 / 25.
- Continuous nominal roof gap: 1.577795 mm at 43.897886°.

These values describe the digital prototype. Vehicle interfaces are unmeasured; welds, stock variation, temperature, deflection and oil-control performance are unqualified. Numeric precision is not manufacturing tolerance or measurement accuracy.

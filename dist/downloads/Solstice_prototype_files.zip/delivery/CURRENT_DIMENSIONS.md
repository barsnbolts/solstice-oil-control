# Current nominal dimensions — generated

Source: `src/design_parameters.py`, both BOMs, saved STEP profile areas, and `concepts/p4/review/validation.json`.
See `DIMENSION_REGISTER.csv` for every input's datum, source, uncertainty and status.

| Concept | Well / inner footprint | Validated nominal CAD envelope | Gates | Cut plates + pins | Installed net cut area | CAD metal mass estimate | Gross window area |
|---|---:|---:|---:|---:|---:|---:|---:|
| A — simple gated well | 160 × 120 mm | 160 × 120 × 47.2192 mm | 3 | 25 + 3 | 349.4 cm² | 336 g | 17.28 cm² |
| B — radial collector | 164 × 154 mm | 212 × 202 × 47.2192 mm | 4 | 34 + 4 | 382.9 cm² | 368 g | 23.04 cm² |
| C — nested reservoir | 136 × 120 mm inner; 224 × 208 mm outer | 224 × 208 × 47.2192 mm | 6 | 45 + 6 | 845.3 cm² | 813 g | 34.56 cm² |

- The shared structural stock / gate leaf are nominally 1.2192 / 0.762 mm; custom stop is 60°.
- A includes 5 loose, undrilled mounting blanks; none of the variants has a vehicle mounting pattern.
- Installed net cut area sums the saved cut profiles with holes removed and excludes A's five loose mount blanks. The CAD mass estimate uses saved assembly solid volume and 7.9 kg/dm³ nominal 304 stainless density ([Outokumpu data sheet](https://otke-cdn.outokumpu.com/-/media/files/products/core/outokumpu-core-range-datasheet.pdf)); it excludes weld filler and unmodeled hardware, and the pin grade remains unresolved.
- Gross window area is the sum of wall cutouts; closed leaves cover those openings. It is not effective open area, flow capacity, or oil-control evidence.
- Continuous nominal roof gap for A: 1.577795 mm at 43.897886°.
- Published pan overall maximum: 474.7 × 316 × 117.99 mm. Interior, cover, pickup, tube and insert placement remain display proxies.
- Illustrative insert-to-floor gap: 3 mm, derived only from the proxy placement and floor inputs; not a flow or operating limit.

These are digital nominal values, not measured fit or manufacturing tolerances. Welds, stock variation, temperature, deflection and oil-control performance are unqualified. Numeric precision does not establish accuracy.

# Current nominal dimensions — generated

Source: `src/design_parameters.py`, both BOMs, and `concepts/p4/review/validation.json`.
See `DIMENSION_REGISTER.csv` for every input's datum, source, uncertainty and status.

| Concept | Well / inner footprint | Validated nominal CAD envelope | Gates | Cut plates + pins |
|---|---:|---:|---:|---:|
| A — simple gated well | 160 × 120 mm | 160 × 120 × 47.2192 mm | 3 | 25 + 3 |
| B — radial collector | 164 × 154 mm | 212 × 202 × 47.2192 mm | 4 | 34 + 4 |
| C — nested reservoir | 136 × 120 mm inner; 224 × 208 mm outer | 224 × 208 × 47.2192 mm | 6 | 45 + 6 |

- The shared structural stock / gate leaf are nominally 1.2192 / 0.762 mm; custom stop is 60°.
- A includes 5 loose, undrilled mounting blanks; none of the variants has a vehicle mounting pattern.
- Continuous nominal roof gap for A: 1.577795 mm at 43.897886°.
- Published pan overall maximum: 474.7 × 316 × 117.99 mm. Interior, cover, pickup, tube and insert placement remain display proxies.
- Illustrative insert-to-floor gap: 3 mm, derived only from the proxy placement and floor inputs; not a flow or operating limit.

These are digital nominal values, not measured fit or manufacturing tolerances. Welds, stock variation, temperature, deflection and oil-control performance are unqualified. Numeric precision does not establish accuracy.

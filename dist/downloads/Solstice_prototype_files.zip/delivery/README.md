# Solstice GXP baffle concepts — fabrication prototypes

**These are digital prototypes, not confirmed drop-in parts or an engine-use release.** The current objective is source-based modeling and virtual fitment; no physical-fit gate blocks that work. The CAD and cut files are reproducible, while hidden pan/pickup geometry and exact mounting coordinates remain visual proxies or unknowns. Do not interpret a digital scenario pass as exact physical fit or engine-use approval.

The current comparison is **A simple gated well**, **B radial collector**, and **C nested reservoir**. A is the former V3 custom-gate design. Read the [A/B/C concept and pan-context notes](../concepts/p4/CONCEPTS.md) and the generated [current dimensions](CURRENT_DIMENSIONS.md). Each parameter's source and uncertainty: [dimension register](DIMENSION_REGISTER.csv). Rebuild through the single check command in [STATUS.md](../STATUS.md).

The current digital sequence is in [next decisions](NEXT_DECISIONS.md); the earlier physical plan is preserved in `../history/NEXT_DECISIONS_PHYSICAL_PLAN_2026-10-13.md`. The [interface evidence](INTERFACE_ASSESSMENT.md) and [tolerance sensitivity](TOLERANCE_SENSITIVITY.md) remain useful for marking unknowns, not as gates to this digital study.

Current A/B/C collision results are in the [digital fit scenario assessment](../review/digital-fit-scenario-assessment.md). Cross-engine analogies, including the Honda source and dimension review, are in [Honda precedents](../research/honda-precedents.md).

The [heading-accessory assessment](../review/heading-accessory-assessment.md) adds static manufacturer-accessory and assumed reaction-saddle scenes. These are assembly-study references, not additional oil-pan kit parts or SendCutSend order items. The source accessory is not a qualified stainless heading tool; fixture material, clamping and load rating remain unresolved.

## Current A/B/C comparison

| Option | Model | Custom cut plates | Process pins | Purpose |
|---|---|---:|---:|---|
| A — Simple gated well | `STEP/solstice_baffle.step` | 25, including 5 loose, undrilled mounting blanks | 3 | Former V3 baseline; simplest current gated design |
| B — Radial collector | `concepts/p4/STEP/radial_collector.step` | 34 | 4 | Tests diagonal collection with open-ended guide vanes |
| C — Nested reservoir | `concepts/p4/STEP/nested_collector.step` | 45 | 6 | Tests staged buffering through an outer reservoir |

The BOM pin rows describe process hardware, not laser-cut sheet parts. B/C quantities exclude the unresolved vehicle mounting system; A's blanks also have no established hole pattern or reach. These are alternatives, not cumulative upgrades or cost/performance rankings. Use only the selected option's BOM and DXFs.

## Retained historical alternatives

V1 fixed dividers and V2 purchased-door proxies remain available in the archived comparison board; they are not current A/B/C choices. V2 gold parts are **simplified purchased-hardware proxies**, not manufacturer CAD. Window and mounting-hole positions follow the [EMR-201 mounting diagram](https://www.improvedracing.com/manuals/download/link/id/74/EMR-20X-KIT%20Instruction%20Manual). Do not cut or fabricate the proxy leaf, barrel or flange. Purchase and measure the real door before reviving that option. A step.parts EMR-201 search returned zero matches; no supplier STEP was found. V2 movement is illustrative only.

## Files and fabrication intent

- Each file in the legacy `DXF/` folder is a distinct flat profile, at 1:1 millimetres, with closed CUT geometry and no pre-applied kerf compensation. The current A/B/C union also includes the separate `concepts/p4/DXF/` profiles. Use the applicable variant BOM; do not order every profile for one option.
- All current structural sheet and hinge cheeks: bare 304 stainless, SendCutSend **SST-048**, nominal **1.2192 mm / .048 in**.
- Moving leaves: bare 304 stainless **SST-030**, nominal **0.762 mm / .030 in**. Small parts and thin leaves require manual finishing; do not assume vendor deburring availability.
- No press-brake operations are specified. Gate cheeks must be joined to their leaves with a qualified process; use the A/V3 coupon to check distortion before a full build. Joining is within the removable insert, **not to the aluminum pan**. A finished hinged assembly is not a laser-cut product.
- A's five 45 × 20 mm blanks are intentionally undrilled and unpositioned. They are transfer-fit stock, not a solved mounting interface. Their reach and thickness may need changing once boss heights and the stock-cover stack are measured.
- Round pins cannot be laser cut from sheet. A uses nominal 3.175 mm stainless round stock; P4 BOMs list nominal 1/8 inch rod. Material grade, bore finish, heading and retention remain process choices to qualify. Do not use loose clips/nuts inside the sump.

The fabrication research records early recommendations, not the final drawing: this prototype uses butt-jig welding (no tabs/slots), 14 × 14 mm fixed cheeks, 3.6 mm bores, and moving-arm contact against the wall as its opening stop. The final wall is 46 mm high, replacing the earlier 35 mm concept assumption. Neither height is verified against the OEM cavity. Small cheek size meets the cited cutting envelope but does not establish weld or fatigue strength.

## A / former V3 fabrication detail

The following dimensions, fit sequence and motion checks describe A/the former V3 design unless explicitly marked historical. They do not define B/C geometry; use the P4 concept notes and BOMs for those designs.

### Coordinate system and assumptions

Origin is the centre of the cage bottom plane. +Z points upward; the relieved tube side is -Y. **These axes are not registered to the actual car.**

| Parameter | Current value | Evidence status |
|---|---:|---|
| Outer frame | 160 × 120 mm | Design choice, not measured pan clearance |
| Wall height / total frame height | 46 / 47.2192 mm | Design choice, not measured lid-to-floor space |
| Tube-side relief width / bottom height | 42 / 22 mm | Provisional keepout; tube identity and position unresolved |
| V1 divider planes | approximately X = ±50 mm | Design choice; pickup clearance unresolved |
| V3 feed window | 36 × 16 mm each, 3 windows | Design choice; 576 mm² per window, untested flow capacity |
| V3 leaf | 44 × 22 × .762 mm | Design choice; 4 mm side and 3 mm vertical overlap at nominal close |
| V3 pivot | 4 mm inward of wall, Z=30 mm | Design choice checked in CAD |
| V3 opening limit | 60° | Actual arm-to-wall stop in nominal CAD; tolerance/bench checks outstanding |
| V3 pin / cut bore | 3.175 / 3.6 mm | Nominal fit; ream/finish/jig after cutting and welding |
| V3 cheek axial gap | .3 mm per side | Nominal; verify after fabrication |
| V2 window | 38.1 × 15.24 mm, lower edge 7.62 mm from datum | Source-dimensioned mounting diagram; datum must match actual sump floor |
| V2 holes | Ø3.2512 mm, spacing19.05 mm, Z40.64 mm | Source-dimensioned; laser tolerance may require final rivet-hole sizing |

The DXF exporter translates profiles to its own planar origin. Use dimensions relative to the cut boundary, not the drawing origin, to locate features. No scaling or geometry change is implied by that translation.

## Future physical build notes (outside active digital scope)

The steps below preserve earlier fabrication and fitting guidance for a later owner-directed build. They are not requirements for the current digital reconstruction, virtual fitment study or completion of the digital package.

1. For a later physical variant, confirm the actual pan and cover identities. Keep the factory stamped cover and press-fit pickup screen. Do not remove the screen to accommodate the concept.
2. Make a full-size nonmetal mock-up from the DXFs before buying cut stainless. Establish actual pickup/screen envelope, floor contour, floor-to-cover heights, all five boss coordinates/heights, dipstick/drain/return paths, and installation/removal path. The top frame DXF is a useful footprint template, not a complete fit test.
3. Resize frame, partitions, tube relief and wall-bottom profiles to those observations. Keep a small controlled bottom clearance without hard contact; no clearance value is approved here. Do not seal a trapped cavity that cannot refill or drain. At only 1 mm gap, the nominal 560 mm outer perimeter already presents roughly 560 mm² of bypass—similar to one V3 window. This estimate is a warning about sensitivity, not a flow calculation.
4. Transfer the verified bosses to the five mounting blanks; determine any required stand-offs. Retain the original cover height, bolt engagement, seating, and rotating-assembly clearance. If the proposed blanks cannot do this, redesign them. Do not simply stack them under stock bolts and assume the original torque remains applicable.
5. Resolve captive-pin forming access before closing the cage. The [digital approach assessment](../review/pin-tool-access-assessment.md) finds the tested coaxial envelopes blocked on completed cages. A prospective early-heading fixture or reduced nose must be qualified with the intended pin and joining process. Dry-fit and tack the cage in a jig. Verify dimensions before final welding. For V1, the divider ends meet the front/rear portions of the top frame. For V2/V3, four walls butt together and meet the top frame. Finish and inspect welded joints; remove all dross, abrasive residue and debris.
6. V2: fit actual EMR-201 doors on the chamber side following the supplier diagram, using solid rivets and the manufacturer procedure. Allow at least the specified 25.4 mm swing space to the pickup, then check the actual door. The supplier intentionally permits a slightly open rest position for refill.
7. V3: jig fixed cheeks perpendicular to the wall. Weld each moving cheek to the inner leaf face over its 14 mm edge (Z10–24 mm), avoiding distortion of the .762 mm sheet. The broad inward arm is intentional. Use a coupon first; reject a distorted or weak joint. Bore alignment and free rotation must be checked after welding.
8. Fit pins and form permanent retention at the qualified assembly stage while maintaining free axial movement. The digital body-size envelopes clear isolated hinge hardware with wall attachment deferred; after wall attachment, only the 6 mm cylinder clears. Do not presume that the final cage permits late heading. Any early-heading sequence must preserve alignment through subsequent joining and finishing. The nominal CAD provides .3 mm head-to-fixed-cheek clearance on each side. Do not upset a pin against the moving cheeks. Check the broad closed seat and both arm stops, deburr the contact edges, and verify free motion after retention and mounting.
9. Bench-check refill/drain behavior and operation with the intended oil over operating temperature. Then verify pressure under controlled conditions before claiming oil-control benefit. No flow, thermal, fatigue, wear or vehicle test has been performed here.

## What has been checked

`review/validation.json` records checks against the saved STEP and DXF files: positive valid solids, declared stock thicknesses, units, CUT-only loops, profile bounds, supplier mounting-hole geometry, stationary intersections, sampled V3 movement in 5° increments, reverse seat and 60° opening-stop behavior. V2 commercial proxies are excluded from clearance certification. Snapshots were generated for each part and assembly; see `review/`.

Successful CAD and supplier-format checks do not establish pan fit, reliable lubrication, final order acceptance or engine-use suitability. Current source comparison is in `research/fabrication.md`; exact selected material records and dated supplier feeds are retained.

## Rebuild

From the project root, run `python` below through:

```sh
uvx --no-config --managed-python --python 3.13 --from cadgen==0.7.21 python
```

Build the selected assembly source under `src/`; build its `<part>_cut.py` scripts for the quantities in `BOM.csv`. `checks/rebuild.py` is the explicit complete-package rebuild. Then run `checks/validate.py`. Keep each STEP with its sibling `.step.json` when present; that file contains native motion/material data.

## Animations and standards

Each option includes a six-second MP4 and an animated GLB with a `demo` clip. `REFERENCE_BOARD.html` plays all three locally; `ANIMATION/` holds videos and `GLB/` holds portable animated 3D files. V1 separates its three assembly pieces for explanation. V2 rotates simplified purchased-door leaf proxies; it does not establish the supplier hardware's shape or actual rest angle. V3 rotates each leaf and its two attached cheeks inward from 0° to 60° and back, with the pins and fixed frame stationary. All gates move together only to make the mechanism easy to see. Real doors respond independently to local oil and acceleration. Six seconds is arbitrary presentation timing, not a predicted opening or closing response.

`QUALITY.md` defines design, modelling and production standards. `review/quality-assessment.md` is the independent Astra Medium review; `review/FINAL_QA.md` records final build and playback closure without rewriting that review's historical evidence. All physical-release holds remain visible.

Complete geometry and animation rebuild commands, from the project root:

```sh
uvx --no-config --managed-python --python 3.13 --from cadgen==0.7.21 python checks/rebuild.py
uvx --no-config --managed-python --python 3.13 --from cadgen==0.7.21 python checks/render_animations.py
python3 checks/build_board.py
python3 checks/package_delivery.py
```

The last command verifies current files, writes SHA-256 manifests and packages this project. It does not run the geometry kernel; run the geometry rebuild first after source edits. Existing still posters are retained as inspected presentation images; the animation renderer produces fresh 0/1.5/3-second review stills.

## P1 continuation — process coupon and continuous roof check

The full variants retain their reviewed geometry. A separate `STEP/v3_hinge_coupon.step` now reuses one existing V3 wall/gate for bench process trials. Use `COUPON_PLAN.md`, `COUPON_BOM.csv`, `COUPON_RESULTS.csv` and `PDF/hinge_inspection_drawing.pdf`; the coupon has six cut pieces plus one pin and introduces no new cut profiles. It has no roof or pan mounts and is not an engine part.

The new analytical roof-height bound is **1.577794898 mm at 43.897886°**, slightly tighter than the earlier sampled 1.580463 mm. `TOLERANCE_BUDGET.md` distinguishes this nominal geometric gap from the unqualified weld/stock/thermal/deflection stack. The drawing is a nominal inspection document, not a production drawing with approved tolerances. `STATUS.md` is the authoritative resumption entry point.

# Next decisions — Solstice GXP baffle prototypes, P3

Decision scope: choose the next measurement or bench article that can retire a real uncertainty. The three model alternatives remain nominal; none has measured installed fit or demonstrated oil-control performance. The accepted P2 package is preserved separately in history with its original hash. See `INTERFACE_ASSESSMENT.md`, `TOLERANCE_SENSITIVITY.md`, the source follow-up and `QUALITY.md`.

## The smallest useful first evidence set

One matching removed pan with its original cover and pickup intact can answer most fit questions in one session. Record the actual pan/cover/fastener markings and photographs before disassembly. Include a scale in the same plane as each photographed feature. Photos alone do not measure hidden depths or thread engagement.

Establish a repeatable pan datum before measuring the cage: label all five cover mounting locations A1–A5 on one overview photo. Select three non-collinear, widely separated, repeatable contact points A1–A3, and define datum plane A through them, origin A1, +U along A1→A2, +N toward the cover, +V to complete a right-handed frame. Record exactly where each probe contacts. This construction does not assert that all five mounting seats are coplanar: record each seat normal, contact footprint and height residual, especially A4/A5. If the chosen points are not repeatably accessible, select another physical datum and document it; do not flatten the seats in CAD by assumption.

Record the transform from this datum to installed car forward/left/up and gravity, and subsequently to the current cage's X/Y/Z. The model's relieved −Y side has no established car direction. Preserve the original cover position and pickup/tube location. Measure the actual assembly rather than transferring a catalog photo's perspective.

The fit session needs these together:

1. All five seat/contact locations, bolt seating surfaces, original clamp stack, fastener identity, under-head length, threaded segment, usable boss depth and actual engagement without bottoming. Record cover seating before any added strap. A partially threaded or thread-forming screw cannot be replaced on the strength of an M6 label alone.
2. Registered cavity/floor sections and cast obstacles across the intended cage footprint, not just maximum width/depth. Record the cover underside/relief, pickup screen/tube and drain route in the same datum. Include local protrusions and the lowest cover areas over each door sweep. A large overall pan envelope cannot close these measurements.
3. Uncertainty and method for every observation: instrument, resolution, calibration/reference check, repeat readings, datum repeatability and access limits. Instrument resolution alone is not measurement uncertainty. Retain raw measurements and photographs under `research/` with traceable filenames, then enter evidence paths and uncertainty in `MEASUREMENTS_REQUIRED.csv`.
4. A complete disposable trial assembly of the candidate envelope, with representative mount, pin-head, weld and purchased-hardware envelopes. Use it only after the measurements establish a plausible location. Check cover seating, independent gate travel, pickup clearance, floor/bypass gaps, insertion/removal and tool access. A single hinge coupon cannot answer full-cage fit.

No fixed minimum pan, pickup, floor or thread-engagement clearance is assigned without applicable evidence and the actual configuration. The dimensional comparison must include measurement uncertainty, process error, temperature and load allowance before a release criterion is chosen.

## Ranked work and its decision

| Rank | Evidence/test | Decision unlocked | Stop or revise when |
|---|---|---|---|
| 1 | Identity, registered seats/stack and cavity/cover/pickup envelope | Can any current architecture fit while retaining the cover and pickup? | No justified placement or mount stack exists. Revise the carrier/envelope before further hinge work. |
| 2 | Intended use, permitted oil/fill, installed attitude and baseline conditions | Which directions, oil states and replenishment conditions must be compared? | Conditions are undefined; performance ranking remains open. |
| 3 | Full disposable fit mock-up and measured gap/path map | Which geometrically feasible variants remain; where are bypass, vent, drain and return paths? | Contact, cover lift, inadequate engagement, obstructed pickup/service or uncontrolled bypass defeats the architecture. |
| 4 | Actual EMR-201 revision and measured hardware sweep/attachment | Is V2 a practical purchased-door route in the measured space? | Supplier envelope/rivet access/retention or operation conflicts with fit; assess another carrier or custom route. |
| 5 | V3 representative welded/finished/retained coupon | Is the owner-made hinge process feasible and repeatable? | Measured distortion, alignment, pin retention, stop contact or resistance cannot meet a justified process/operating budget. Revise the process or geometry from the failed measurement. |
| 6 | Comparable bench refill, retention, vent and drain trials of feasible variants and stock baseline | Do gates add a useful benefit without restricting supply/recovery or service? | A variant improves retention while failing refill, drainage or air handling under the same recorded conditions. |
| 7 | Full fitted assembly inspection, justified thermal/load/cycle exposure and reinspections | Can one named as-built unit progress beyond bench development? | Binding, movement, cracks, debris, loss of clearance or retention occurs. Preserve the failed article/results. |
| 8 | Instrumented baseline versus modified oil-pressure behavior | Does the named unit behave acceptably in its defined use? | Predefined applicable abort limits are reached; no unrestricted engine-use conclusion follows from a bench or animation. |

`MEASUREMENT_PRIORITY.csv` maps every one of the 29 existing unknown worksheet items to these ranks. Ranks are dependency/decision priorities, not estimates of safety or test effort. Ranks can overlap: stock and rivet traceability must precede the V2 attachment trial as well as V3 coupon fabrication. Coupon work can proceed independently of pan measurement, but its result does not close ranks 1–3.

## Choose among the three with the same conditions

Keep the unmodified OEM system as a fourth comparison baseline. V1 is the lowest-part-count prototype and removes hinge-process uncertainty; its refill and directional retention still need evidence. V2 removes custom hinge fabrication but depends on the real purchased door, its attachment and installed motion. V3 allows custom packaging but adds joining, alignment, thin-leaf distortion, pin-heading and fatigue questions. The current V2 preference reflects fabrication effort only.

A variant becomes the next fitted prototype when its measured envelope and attachment are feasible and its specific mechanism/process trial is credible. Select the final architecture only after common-condition refill/retention evidence and the physical holds in QUALITY.md are addressed. Record why alternatives were rejected using actual measurements, not the number of doors or how the render looks.

## Quantities to record in the decisive bench comparison

Use the same oil specification, measured temperature, orientation/effective-gravity scenario, initial inventory and fixture geometry for each comparison. Identify fixture leakage separately. Record upstream/downstream levels, differential head, door angle/initiation/recovery, time-resolved supplied/drained volume, trapped air, residual oil and repeatability. Run the stock baseline through the same observable conditions. State which real operating conditions the fixture cannot reproduce.

If level measurements have uncertainties u1 and u2, a conservative differential-head uncertainty is u1+u2 unless a justified correlated model is available. Compare an opening-initiation head with the measured available refill-head range and uncertainty; do not adopt an arbitrary universal opening-head target. Similarly, a simple chamber balance dV/dt = Q_in − Q_pickup − Q_out is a bookkeeping check only after those flows and usable inventory are established. Window area, floor-gap area and enclosed geometric volume alone do not predict those flows or starvation time.

Before each physical test, record the named revision, method, observable pass/fail question, justified loads/conditions and stop criteria. Use the coupon results template as a template and retain raw repeats in a separate evidence file. No physical test has been performed in this project packet.

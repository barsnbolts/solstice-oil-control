# Next decisions — digital reconstruction and fitment, P5

This plan is for the **digital modeling objective**. No physical pan measurement, mock-up, coupon, bench test or engine test is a prerequisite to continuing or completing this work. The preserved physical measurement/test plan is available at `../history/NEXT_DECISIONS_PHYSICAL_PLAN_2026-10-13.md` if a later build is separately requested.

## What digital fitment means here

Build the most accurate editable Solstice GXP pan and insert model supported by available sources, then test each concept against explicitly named reconstructed scenarios. A virtual pass means clearance against those stated digital surfaces and ranges. It does not convert an image-derived or assumed surface into exact OEM geometry, and does not claim fit to a particular physical pan.

The firm dimensional anchor is the published **GM 12601240 overall maximum envelope: 474.7 × 316 × 117.99 mm** ([GM product specification](https://parts.gmparts.com/product/gm-genuine-parts-engine-oil-pan-12601240)). Catalog and service sources identify the Solstice pan/cover/baffle family, five baffle fasteners, pickup topology, and related fastener identities. They do not supply the hidden cavity, cover relief, pickup envelope, boss coordinates, seat heights or an installed-car transform. No matching 12601240 CAD model or dimensioned internal drawing surfaced in the recorded search.

## Ranked digital work

| Rank | Work | Digital decision it supports |
|---|---|---|
| 1 | Reconcile official GM 12601240 product photos, catalog facts and service references with current Honda/other-engine examples. Honda architecture and pan-envelope examples are in `research/honda-precedents.md`. The Vue service figures are application-unresolved or an LY7/12666374 analog, as documented in `research/same-pan-family-visuals.md`. | Which geometry/features are supported, visible only, or still unknown? |
| 2 | Compare the official exact-part Solstice pan photos with Vue inspection/assembly illustrations only as qualified visual analogs. Use them for labels and qualitative topology; keep raw pixel observations and any photo-derived estimates separate from adopted dimensions. | What is the best evidence-bound digital pan context, and where must alternatives remain? |
| 3 | Four one-variable exact-BRep scans now bracket the first detected intersections for cover height, pickup keepout diameter, tube diameter and pan-interior scale. Results and coarse-step limits are in `review/digital-fit-scenario-assessment.md`. Next, use source-backed evidence to narrow proxy dimensions and positions; add coupled cases only where evidence supports changing inputs together. | Which concepts remain clear across explicit digital sensitivities, and which new evidence would reduce the dominant uncertainty? |
| 4 | Refine A/B/C and any justified additional style: footprint, height, tube relief, flow windows, gate count/orientation, open/fixed partitions, vents, drains, service and insertion path. `CURRENT_DIMENSIONS.md` now compares BOM-derived net cut area, saved-solid stainless mass estimates, moving-gate mass and gross gate-window area alongside part count and envelope. | Which architecture is simplest and least sensitive to the currently uncertain interfaces? |
| 5 | Sampled vertical withdrawal, eight declared shift/tilt-before-lift routes per concept, and a mass-only gravity-torque sweep are implemented. All 24 selected alternative paths meet the nominal fixed tube or shell proxy at a sampled pose; this does not show that every route is blocked. The torque study evaluates every gate over 0–60° in seven total directions and shows level closing bias for all gates plus direction-dependent opening bias for some gates. | Which assumptions control the result, and which variants have a feasible modeled assembly/service path? |
| 6 | Captive-pin approach checks now cover 26 ends, three cylindrical diameters and four assembly stages (312 checks). Isolated hinge hardware clears all three before wall attachment; wall-attached modules clear only Ø6, and completed cages block the tested coaxial routes. See `review/pin-tool-access-assessment.md`. The sourced HL-200 accessory and assumed reaction saddle add 104 combined stage assessments with early-stage clearance and later-stage fixture obstructions; see `../review/heading-accessory-assessment.md`. Keep actual machine kinematics, complete powerhead/contact/clamp geometry, joining access and missing OEM mount/boss coordinates explicit. | Which modeled interfaces have a plausible approach direction, and where does missing geometry dominate? |
| 7 | Regenerate CAD, STEP/DXF, motion previews, dimensional register and review atlas from the shared parameter source. Update the phone-readable GitHub Pages review after the local candidate passes mandatory checks and the current independent review gate. | Is the current package reproducible, internally consistent and easy to compare? |

## Current options and variables to keep in view

- **A — simple gated well:** fewest current custom gates; directional retention and refill area remain design hypotheses.
- **B — radial collector:** diagonal gates and guide vanes broaden the collection directions; larger envelope and more seams.
- **C — nested reservoir:** two stages and six gates test buffering; largest part count/envelope and most complex refill path.
- **Historical alternatives:** fixed dividers and purchased-gate proxies stay available for comparison; purchased proxy geometry is not supplier CAD.

Across the options, inspect horizontal footprint and rotation, vertical height, floor step, wall/floor bypass, cover and rotating keepouts, pickup/screen/tube envelope, drain/return/vent paths, gate opening/closing direction, independent gate poses, removal path, cleanliness/service access, material thickness, part count, mass, process features, and sensitivity to parameter changes. Treat oil viscosity, available head, acceleration/gravity cases, oil inventory and flow as separate physical phenomena: CAD area/volume is only geometry, not a flow or starvation prediction.

## Digital completion criteria

The digital candidate is complete when the named source evidence and assumptions are traceable; the editable pan/cover/pickup/insert assemblies are inspectable; A/B/C are compared in common frames and declared digital scenarios; interference and motion checks cover the stated poses and surfaces; source STEP/DXF profiles and BOMs agree; animations are visibly illustrative; and the review page says what is source-backed, inferred and unknown. Any unbounded hidden interface remains visibly uncertain instead of blocking the digital deliverable.

Physical manufacture, installation, service life and oil-pressure performance are outside this digital completion criterion. If a later physical build is requested, the existing `QUALITY.md` fabrication and engine-use checks apply as a separate release decision.

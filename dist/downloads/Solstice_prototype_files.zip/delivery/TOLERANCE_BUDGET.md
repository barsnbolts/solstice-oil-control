# Functional clearance budget — current nominal design

P3 companion: [TOLERANCE_SENSITIVITY.md](TOLERANCE_SENSITIVITY.md) supplies reproducible conditional calculations, break-even thresholds and unknown contributors. The table below remains the physical closure register.

This is a list of margin contributors to measure, not a completed tolerance analysis. The source geometry is nominal. Quoted supplier cut tolerance ±.005 in (±.127 mm) and SST-048 thickness tolerance ±.003 in (±.0762 mm) are retained in `research/fabrication-assets/selected-material-records.json`; the source feed was retrieved 2026-10-13 and generated 2026-04-29. These values are not silently assigned to a welded or reamed assembly. Confirm supplier interpretation and actual stock at release.

| Interface | Nominal available margin | Variables that consume/change it | Required closure |
|---|---:|---|---|
| Leaf/cheek group to top-frame underside | 1.577795 mm continuous lower bound at 43.897886° | Cut contour and pivot location; bore play; weld bead/warping; wall/frame squareness; mounting distortion; thermal growth; deflection | Bound signed stack against measured geometry and inspect actual full assembly over travel |
| Bore minus pin diameter | 3.6 − 3.175 = .425 mm diametral | Hole size/taper/burr; pin diameter/roundness; four-bore coaxiality; weld distortion; galling/wear; oil film/contamination | Measure bores and pin; align/finish after welding; test assembled motion across stated conditions |
| Moving/fixed cheek gap, each side | .300 mm | Relative cheek center-plane location and both sheet thicknesses; welding distortion; tilt/flatness | Measure both gaps independently after joining and retention |
| Head/fixed-cheek gap, each side | .300 mm | Finished head inner position/free span; fixed-cheek center-plane position and thickness; upset distortion | Measure both final head gaps and prove pin captivity without binding |
| Leaf overlap at closed seat | 4 mm each side, 3 mm top/bottom | Window/leaf profile error; relative hinge position; skew; seat warping; wear | Verify all four overlaps and broad seating on actual coupon and installed assembly |
| Stop angle and paired contact | Nominal 60°, two arm contacts | Stop-profile error; bore play; wall/cheek squareness; weld shrinkage; impact deformation | Measure both contacts and angle; qualify impact/retention separately |
| Pin retention geometry | Modeled Ø6 × 1.2 heads | Rod condition; raw allowance; heading process; cracks; shaft distortion; pull-through strength | Specify process through coupon; no strength acceptance from CAD diameter alone |
| Pan/cover/pickup/mount clearance | UNKNOWN | Actual casting and pickup geometry, OEM stack, mounting load, floor profile and service envelope | Complete measurement register before assigning a tolerance or clearance |

For the moving/fixed gap, the nominal formula is:

`gap = fixed_center − moving_center − (fixed_thickness + moving_thickness)/2`

If both SST-048 cheeks are .0762 mm thicker **and their center planes remain at their nominal coordinates**, thickness alone reduces a .300 mm gap to .2238 mm. This is only a sensitivity case; real jigs may locate faces rather than center planes, changing the stack. Unknown placement and weld errors prevent a guaranteed residual margin.

The .425 mm diametral difference is not radial free movement, a specified bearing fit or a guarantee that four bores will align. A bore may meet its diameter requirement while the assembled pin still binds. Likewise, do not apply the generic cutting tolerance to a finished bore without checking how the supplier defines it and what post-weld finishing achieves.

The continuous roof calculation evaluates the extrema of every outer polyhedral moving-group vertex over 0–60°. Circular bores remove material, so they cannot increase this exterior height. Its plane at Z=46 conservatively covers the entire frame underside. This closes the between-sample **nominal roof-height** question only; it does not add welds, physical variation, or a continuous collision proof against every fixed component. The older 1.580463 mm result remains the sampled value, not the controlling continuous bound.

No root-sum-square statistical stack is used without measured distributions. Unknown errors stay unknown. Select achievable process tolerances only after the intended fixture, welding and finishing process has been demonstrated.

# Cut-file preflight — 2026-10-13

Scope: flat laser cutting only, bare SST-048 structural plates and SST-030 V3 leaves. No bending, tapping, countersinking, hardware insertion or finishing service is assumed. Quantities are in BOM.csv. **Overall order readiness: held for pan fit and mounting definition.**

Current official sources were retrieved directly on 2026-10-13; catalog/spec feeds identify 2026-04-29 generation. Their age and deburring conflicts are recorded in `research/fabrication.md`. No actual configurator upload or price quote was performed.

| Check | Measured file fact | Comparison | Rule source |
|---|---|---|---|
| Units / scale | All 11 DXFs use INSUNITS=4; bounds match corresponding STEP flat part within .001 mm | Pass for millimetre profile exchange | [Ordering guide](https://cdn.sendcutsend.com/specs/sendcutsend-ordering-guide.md), file preparation |
| Contours | All 11 passed cadgen saved-file validation for closed cuts, duplicates and degeneracy; CUT layer only | Pass | [Ordering guide](https://cdn.sendcutsend.com/specs/sendcutsend-ordering-guide.md), clean vector geometry; direct DXF inspection |
| Stock size | Smallest rectangular envelope 14 × 14 mm; largest 160 × 120 mm | Pass against 9.525 × 6.35 mm minimum and 1117.6 × 762 mm maximum | [Specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), materials[sku=SST-048/SST-030].cutting_specs |
| Hole diameters | V2 rivet holes3.2512 mm; V3 hinge holes3.6 mm | Pass versus cited minima, also larger than conservative half-thickness rule | [Specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), selected SKU cutting_specs.min_hole_size; [deburring guidance](https://sendcutsend.com/services/deburring-services/) |
| Internal hole-to-outline spacing | Measured and retained per part in validation.json; fixed cheek minimum2.2 mm, moving cheek above1 mm, V2 above3 mm | Above .508 mm exact-SKU hole-to-edge minimum | [Specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), SST-048 cutting_specs; saved STEP measurements |
| Thin sections / profile webs | Top frame12 mm; wall border minimum6 mm around windows; hinge-hole ligaments measured separately. Moving arm's terminal contact edge is intentionally narrow and manually finished | No measured minimum-web violation; no fatigue approval | [Specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), cutting_specs.min_bridge_size; direct geometry |
| Thickness | Structural parts1.2192 mm, leaf.762 mm in STEP; stock thickness selected separately in ordering | Pass nominal CAD/material correspondence | [Catalog](https://cdn.sendcutsend.com/specs/sendcutsend-catalog.json), exact SST-048 and SST-030 records; [specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), general_specs |
| Flatness / tolerance | Source nominal profiles; no laser, stock, weld or thermal tolerance simulation | Fit/hinge qualification required | [Specs](https://cdn.sendcutsend.com/specs/sendcutsend-specs.json), cutting tolerance ±.005 in and thickness tolerance |
| Deburring | Small cheeks and .030-in leaves fall outside/contradict published deburring limits | Manual finishing specified; no vendor-service readiness claim | [Deburring service](https://sendcutsend.com/services/deburring-services/), .048-in minimum thickness and1×3-in minimum size; conflicts recorded |
| Mounts and floor profile | Mount blanks undrilled, cage height/floor contours unmeasured | Need actual pan evidence before final order | Direct project evidence; no supplier rule can establish vehicle fit |

The V2 mounting drawing specifies .128-in rivet holes. Laser tolerance can leave them undersize relative to a 1/8-in rivet; final hole sizing and grip selection are owner operations. The V3 3.6-mm bore is a nominal clearance envelope, not a guaranteed running bearing after welding.

Supplier acceptance may still differ at upload. These checks establish a usable prototype file package, not a SendCutSend-ready engine part.

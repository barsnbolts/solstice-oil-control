# V3 single-gate process coupon — P1

**Purpose:** learn whether the current thin-sheet hinge can be made, retained and operated repeatably before committing a full cage. This is a bench article, not an engine part. Its geometry is taken directly from the current V3 wall, leaf, cheeks and pin. No new cut shapes or vehicle measurements are introduced.

Use `STEP/v3_hinge_coupon.step` with its sidecar, `PDF/hinge_inspection_drawing.pdf`, `COUPON_BOM.csv` and the existing named DXFs. The five-page PDF supplies nominal inspection views of the wall, leaf, both cheek shapes and complete coupon. It is not a toleranced production drawing; the DXFs remain the full profile authority. P1 adds documentation and a test article, not a new fit-approved V3 design.

## What it can establish

A representative coupon can expose leaf warping, inadequate joining, non-coaxial bores, pin-heading squeeze, edge interference, stop imbalance, friction, stiction and difficult assembly access. It can measure opening initiation and recovery under specified conditions. It cannot establish pan fit, mounts, pickup clearance, full-cage stiffness, roof contact, usable oil capacity, vehicle oil return or oil-pressure protection. There is no roof on this coupon. Use the full fitted assembly for those questions.

## Parts and nominal placement

Six laser-cut pieces: one side wall, one leaf, two fixed cheeks and two moving cheeks. Add one owner-finished pin. Five pieces use SST-048, 1.2192 mm; the leaf uses SST-030, .762 mm. Choose this coupon BOM separately from the three full-variant BOMs; it is not automatically an extra set in an order.

Coordinates are local to this wall: X along the wall, +Y toward the chamber, Z upward. The wall's inner seat is Y=0 and its bottom is Z=0. These axes are not registered to the car.

| Feature | Nominal placement or size | Meaning |
|---|---:|---|
| Wall | 120 × 46 × 1.2192 mm | Existing V3 side wall; 36 × 16 window |
| Window | X=−18…18; Z=6…22 mm | Flow aperture before door opening |
| Leaf | X=−22…22; Z=3…25; Y=0….762 mm | Broad closing seat, 4 mm side / 3 mm vertical overlap |
| Pin axis | Y=4; Z=30 mm, along X | Common axis through four cheek bores |
| Moving-cheek center planes | X=−20 and +20 mm | Same handed profile on both sides |
| Fixed-cheek center planes | X=−21.5192 and +21.5192 mm | .30 mm nominal moving/fixed gap at each side |
| Moving-cheek/leaf seam | Y=.762, Z=10…24 mm | 14 mm contacting edge; extent/process to qualify |
| Fixed-cheek/wall seam | Y=0, Z=26…40 mm | 14 mm contacting edge; extent/process to qualify |
| Finished head inner-face separation | 44.8576 mm | .30 mm clearance from each fixed cheek to its head |
| Modeled final pin envelope | Ø3.175 shaft; Ø6 × 1.2 heads; 47.2576 mm total length | Geometric retention proxy, not a proven heading specification |
| Nominal stops | Closed 0° and open 60° | Broad leaf seat; both moving-arm edges contact wall at open stop |

**Raw rod length is not 47.2576 mm by default.** Heading consumes stock and changes length. Select rod condition, heading method and allowance through a separate trial; record finished free span and head dimensions. The CAD head diameter/thickness have no retention-strength approval. Do not substitute an unspecified loose clip or washer.

## Fabrication and inspection sequence

1. Record stock grade/lot, actual sheet/pin dimensions, supplier profile condition and chosen joining/heading process. Preserve the initial part photos and cut-edge condition.
2. Deburr and account for every removed tab, bore slug and particle. Protect seat overlap, the stop edges and the narrow moving-cheek ligament. Measure critical features before joining.
3. Hold the wall in a removable external fixture with access to both fixed-cheek seams. Locate bores to a common axis using appropriate fabrication tooling; do not use the final running pin as a weld fixture. Define temporary fixture material/release method with the fabricator. Keep clamp loads out of the moving leaf and record clamp positions so fixture distortion is reproducible.
4. Qualify moving-cheek-to-leaf joining on the actual .762 mm leaf. Measure flatness and relative cheek position before and after welding. Include the actual weld bead in clearance and moving-mass checks; the nominal CAD contains no weld bead.
5. Finish/align bores as required after joining. Record each bore, actual pin diameter, cheek-side gaps and head-side gaps separately. Dry-assemble before final pin retention. Verify both open-stop contacts and the broad closed seat without forcing the arm past its stop.
6. Form permanent pin retention with suitable support and access. Measure finished free span and both heads. Recheck all clearances, seat/stop contact and free travel after heading. Account for heading chips/fragments and all temporary tooling.
7. Keep the coupon identified as a test article. Retention/load testing may be destructive; a tested coupon does not become an engine-use part merely because it survives.

## Bench measurements

Use `COUPON_RESULTS.csv` as a blank record; duplicate rows for repeats and conditions. Record method, units, instrument resolution/uncertainty, fixture orientation, oil specification/temperature and part revision. An empty value means **not tested**, not zero or pass.

- **Dry mechanical baseline:** record moving mass including welds, bore/shaft sizes, each axial gap, leaf flatness, full travel and both stop contacts. A temporary force measurement at a measured lever arm may estimate opening resistance; record the applied direction and compensate or account for the test attachment's own weight. Do not equate hand feel with a force measurement.
- **Oil-wetted operation:** measure opening initiation, travel/recovery and repeatability using the intended oil at defined cold/hot conditions and orientations derived from the service envelope. Watch for seat-film adhesion after dwell. Gravity bias can change under effective acceleration; a static tilt only covers the orientation tested.
- **Refill/head screening:** if a separate test reservoir is used, describe and measure its seals, liquid levels and bypass paths. Record differential head, opening angle and time/volume response. Separate fixture leakage from window flow. This single-wall result cannot predict complete-pan replenishment or slosh.
- **Retention and cycling:** define justified loads, cycles, temperature exposure and failure criteria before testing. Reinspect for pin movement, cracks, permanent deformation, changed gaps, debris and altered opening behavior. No universal cycle count, force, clearance or opening-time threshold is assigned here.

A measured result closes only its specific question under its recorded conditions. Before a full fabrication release, resolve vehicle geometry/mounts and the full tolerance/weld/thermal stack under `QUALITY.md`. Before engine use, complete the fitted-assembly and instrumented oil-pressure validation stages.

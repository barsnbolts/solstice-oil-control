Solstice GXP nominal prototype exports, P5 digital fitment refinement. Fit and engine-use release held.
Use delivery/BOM.csv for variant quantities and DXF paths; do not order all profiles.
Source CAD is under src/ and uses pinned cadgen==0.7.21. Native animation sidecars accompany STEP files.
This curated public export is not the complete local validation/evidence workspace.
Read the fabrication, uncertainty and measurement notes before bench work.
